# MAP573-Group9
DataScience Project - Time Series Forcasting - Energy Forcasting

Google Slide: https://docs.google.com/presentation/d/1prv4l1Jq7GSpTMgWe9V9szEKBz0q34k8-DRlWQj4pXc/edit?usp=sharing


This is a list of tasks to be done, please update as you progress :

1. Data Visualization (Done)
2. Data pre-processing (Missing values, sampling ...) official link of full data #todo 2 different csv, one with only missing values, one with value with blind weeks must merge them ! link : https://www.dropbox.com/s/epj9b57eivn79j7/GEFCom2012.zip?dl=0&file_subpath=%2FGEFCOM2012_Data%2FLoad link : http://blog.drhongtao.com/2016/07/gefcom2012-load-forecasting-data.html
3. Simple regression methods (using simple Missing value methods)



**Useful links:**

Time-series analysis link:https://otexts.com/fpp2/components.html 

In R link:http://r-statistics.co/Time-Series-Forecasting-With-R.html

“How to use auto.arima to impute missing values”: link: https://stats.stackexchange.com/questions/104565/how-to-use-auto-arima-to-impute-missing-values

"seasonal & trend extraction in R": link:https://anomaly.io/seasonal-trend-decomposition-in-r/index.html
